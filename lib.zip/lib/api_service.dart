import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl =
      "https://lt9e0fj1favccw8wxgggl2d2.deploy.splsystems.in";

  Future<bool> getTodayStatus(String deviceId) async {
    final res = await http.get(
      Uri.parse('$baseUrl/status/today'),
      headers: {'x-device-id': deviceId},
    );

    return jsonDecode(res.body)['done'];
  }

  Future<Map?> getLatest(String deviceId) async {
    final res = await http.get(
      Uri.parse('$baseUrl/logs/latest'),
      headers: {'x-device-id': deviceId},
    );

    return jsonDecode(res.body)['data'];
  }

  /// Throws an [Exception] if the server returns a non-2xx status code.
  /// This ensures [SyncService] only marks entries as synced on real success.
  Future<void> createLog(String deviceId, String id, DateTime time) async {
    final res = await http.post(
      Uri.parse('$baseUrl/log'),
      headers: {
        'Content-Type': 'application/json',
        'x-device-id': deviceId,
      },
      body: jsonEncode({
        'id': id,
        'timestamp': time.toIso8601String(),
      }),
    );

    if (res.statusCode != 200 && res.statusCode != 201) {
      debugPrint('[createLog] FAILED ${res.statusCode}: ${res.body}');
      throw Exception('createLog failed: ${res.statusCode} ${res.body}');
    }

    debugPrint('[createLog] OK ${res.statusCode} id=$id');
  }

  Future<List> getRecent(String deviceId) async {
    final res = await http.get(
      Uri.parse('$baseUrl/logs/recent'),
      headers: {'x-device-id': deviceId},
    );

    return jsonDecode(res.body)['data'] ?? [];
  }

  Future<bool> deleteLog(String deviceId, String id) async {
    try {
      final res = await http.delete(
        Uri.parse('$baseUrl/log/$id'),
        headers: {
          'Content-Type': 'application/json',
          'x-device-id': deviceId,
        },
      );
      debugPrint('[deleteLog] DELETE /log/$id → ${res.statusCode} ${res.body}');
      return res.statusCode == 200 || res.statusCode == 204 || res.statusCode == 404;
    } catch (e) {
      debugPrint('[deleteLog] Exception: $e');
      return false;
    }
  }
}